package server;

import applicationimpl.ChangeOrderImpl;
import applicationimpl.ExpenseBudgetImpl;
import applicationimpl.MaterialEquipmentImpl;
import applicationimpl.ProjectManagementImpl;
import applicationimpl.UserManagementImpl;
import applicationimpl.WorkforceManagementImpl;
import io.javalin.Javalin;
import model.ChangeOrder;
import storageimpl.DatabaseManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/*
 * Starts the AndraCorp backend server.
 * The React frontend communicates with
 * this server using HTTP requests.
 */
public class AndraCorpServer {

    public static void main(String[] args) {

//      Creates the SQLite database and tables
//      before starting the backend.
        DatabaseManager.initializeDatabase();


//      Creates the project management components.
        ProjectManagementImpl projectManager =
                new ProjectManagementImpl();

        ExpenseBudgetImpl expenseManager =
                new ExpenseBudgetImpl();
        
//      Creates the materials and equipment component.
        MaterialEquipmentImpl materialManager =
                new MaterialEquipmentImpl();


//      Creates the workforce management component.
        WorkforceManagementImpl workforceManager =
                new WorkforceManagementImpl();
        
//      Creates the user management component.
        UserManagementImpl userManager = new UserManagementImpl();
        
//      Handles project change orders.
        ChangeOrderImpl changeOrderManager = new ChangeOrderImpl();


//      Creates the HTTP server.
        Javalin app =
                Javalin.create(config -> {

//                  Allows the React frontend
//                  to communicate with this server.
                    config.bundledPlugins
                            .enableCors(cors -> {

                                cors.addRule(rule -> {

                                    rule.allowHost(
                                            "http://localhost:5173");
                                });
                            });
                });


//      Simple route used to test the backend.
        app.get("/api/test", ctx -> {

            ctx.result(
                    "AndraCorp backend is running!");
        });
        

//      Creates a new client account.
        app.post("/api/clients", ctx -> {
            Map<String, Object> request = ctx.bodyAsClass(Map.class);

            Object nameValue = request.get("name");
            Object emailValue = request.get("email");
            Object phoneValue = request.get("phoneNumber");

            if (!(nameValue instanceof String name) || name.isBlank()
                    || !(emailValue instanceof String email) || email.isBlank()
                    || (phoneValue != null && !(phoneValue instanceof String))) {
                ctx.status(400).json(Map.of(
                        "error", "Valid client name, email, and phone number are required."
                ));
                return;
            }

            if (!email.trim().matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) {
                ctx.status(400).json(Map.of(
                        "error", "Enter a valid email address."
                ));
                return;
            }

            String phoneNumber = phoneValue == null
                    ? null : ((String) phoneValue).trim();

            String clientId = userManager.createUser(
                    name.trim(), email.trim(), phoneNumber, "CLIENT"
            );

            if (clientId == null) {
                ctx.status(500).json(Map.of(
                        "error", "Could not create client."
                ));
                return;
            }

            Map<String, Object> response = new HashMap<>();
            response.put("clientId", clientId);
            response.put("name", name.trim());
            response.put("email", email.trim());
            response.put("phoneNumber", phoneNumber);
            response.put("role", "CLIENT");

            ctx.status(201).json(response);
        });
        
        // Client login using their name and phone number.
        // For local capstone demonstration only.
        app.post("/api/client/login", ctx -> {

            Map<String, Object> request;

            try {
                request = ctx.bodyAsClass(Map.class);
            } catch (Exception e) {
                ctx.status(400).json(Map.of(
                        "error", "Invalid request body."
                ));
                return;
            }

            String name = request.get("name") instanceof String
                    ? (String) request.get("name") : null;

            String phoneNumber = request.get("phoneNumber") instanceof String
                    ? (String) request.get("phoneNumber") : null;

            if (name == null || name.isBlank()
                    || phoneNumber == null || phoneNumber.isBlank()) {

                ctx.status(400).json(Map.of(
                        "error", "Name and phone number are required."
                ));
                return;
            }

            Map<String, String> client =
                    userManager.findClientByNameAndPhone(
                            name, phoneNumber
                    );

            if (client == null) {

                ctx.status(401).json(Map.of(
                        "error", "Client not found. Check your name and phone number."
                ));
                return;
            }

            ctx.status(200).json(Map.of(
                    "message", "Client found.",
                    "client", client
            ));
        });

        // Retrieves all registered clients.
        app.get("/api/clients", ctx -> {
            ctx.json(userManager.getAllClients());
        });

        // Updates an existing client's information.
        app.put("/api/clients/{id}", ctx -> {
            String clientId = ctx.pathParam("id");
            Map<String, Object> request = ctx.bodyAsClass(Map.class);

            Object nameValue = request.get("name");
            Object emailValue = request.get("email");
            Object phoneValue = request.get("phoneNumber");

            if (!(nameValue instanceof String name) || name.isBlank()
                    || !(emailValue instanceof String email) || email.isBlank()
                    || (phoneValue != null && !(phoneValue instanceof String))) {
                ctx.status(400).json(Map.of(
                        "error", "Valid client name and email are required."
                ));
                return;
            }

            if (!email.trim().matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) {
                ctx.status(400).json(Map.of(
                        "error", "Enter a valid email address."
                ));
                return;
            }

            // Makes sure the account belongs to a client.
            String checkSql = """
                    SELECT 1 FROM users
                    WHERE user_id = ? AND UPPER(role) = 'CLIENT';
                    """;

            try (Connection connection = DatabaseManager.getConnection();
                 PreparedStatement statement = connection.prepareStatement(checkSql)) {

                statement.setString(1, clientId);

                try (ResultSet result = statement.executeQuery()) {
                    if (!result.next()) {
                        ctx.status(404).json(Map.of(
                                "error", "Client not found."
                        ));
                        return;
                    }
                }
            } catch (SQLException e) {
                ctx.status(500).json(Map.of(
                        "error", "Could not verify client."
                ));
                return;
            }

            String phoneNumber = phoneValue == null
                    ? null : ((String) phoneValue).trim();

            boolean updated = userManager.updateUser(
                    clientId, name.trim(), email.trim(), phoneNumber
            );

            if (!updated) {
                ctx.status(500).json(Map.of(
                        "error", "Could not update client."
                ));
                return;
            }

            ctx.json(Map.of(
                    "clientId", clientId,
                    "message", "Client updated successfully."
            ));
        });
        
        

        // Removes a client only if they have no project history.
        app.delete("/api/clients/{id}", ctx -> {
            String clientId = ctx.pathParam("id");

            String checkSql = """
                    SELECT
                        (SELECT COUNT(*) FROM users
                         WHERE user_id = ? AND UPPER(role) = 'CLIENT') AS client_count,
                        (SELECT COUNT(*) FROM projects
                         WHERE client_id = ?) AS project_count,
                        (SELECT COUNT(*) FROM change_orders
                         WHERE client_id = ?) AS order_count;
                    """;

            try (Connection connection = DatabaseManager.getConnection();
                 PreparedStatement statement = connection.prepareStatement(checkSql)) {

                statement.setString(1, clientId);
                statement.setString(2, clientId);
                statement.setString(3, clientId);

                try (ResultSet result = statement.executeQuery()) {
                    result.next();

                    if (result.getInt("client_count") == 0) {
                        ctx.status(404).json(Map.of(
                                "error", "Client not found."
                        ));
                        return;
                    }

                    if (result.getInt("project_count") > 0
                            || result.getInt("order_count") > 0) {
                        ctx.status(409).json(Map.of(
                                "error", "Client has project or change order history and cannot be deleted."
                        ));
                        return;
                    }
                }
            } catch (SQLException e) {
                ctx.status(500).json(Map.of(
                        "error", "Could not verify client assignments."
                ));
                return;
            }

            boolean deleted = userManager.deleteUser(clientId);

            if (!deleted) {
                ctx.status(500).json(Map.of(
                        "error", "Could not delete client."
                ));
                return;
            }

            ctx.json(Map.of(
                    "clientId", clientId,
                    "message", "Client deleted successfully."
            ));
        });

        // Assigns an existing client to a project.
        app.put("/api/projects/{id}/client", ctx -> {
            String projectId = ctx.pathParam("id");
            Map<String, Object> request = ctx.bodyAsClass(Map.class);

            Object clientValue = request.get("clientId");

            if (!(clientValue instanceof String clientId)
                    || clientId.isBlank()) {
                ctx.status(400).json(Map.of(
                        "error", "Client ID is required."
                ));
                return;
            }

            // Checks that the selected user is a registered client.
            String checkClientSql = """
                    SELECT 1 FROM users
                    WHERE user_id = ? AND UPPER(role) = 'CLIENT';
                    """;

            try (Connection connection = DatabaseManager.getConnection();
                 PreparedStatement statement = connection.prepareStatement(checkClientSql)) {

                statement.setString(1, clientId);

                try (ResultSet result = statement.executeQuery()) {
                    if (!result.next()) {
                        ctx.status(404).json(Map.of(
                                "error", "Client not found."
                        ));
                        return;
                    }
                }
            } catch (SQLException e) {
                ctx.status(500).json(Map.of(
                        "error", "Could not verify client."
                ));
                return;
            }

            // Checks that the project exists and is not archived.
            model.Project existingProject = null;

            for (model.Project project : projectManager.getAllProjects()) {
                if (projectId.equals(project.getProjectId())) {
                    existingProject = project;
                    break;
                }
            }

            if (existingProject == null) {
                ctx.status(404).json(Map.of(
                        "error", "Project not found."
                ));
                return;
            }

            if ("ARCHIVED".equals(existingProject.getStatus())) {
                ctx.status(409).json(Map.of(
                        "error", "Cannot assign clients to archived projects."
                ));
                return;
            }

            boolean assigned = projectManager.addClientToProject(
                    projectId, clientId
            );

            if (!assigned) {
                ctx.status(500).json(Map.of(
                        "error", "Could not assign client."
                ));
                return;
            }

            ctx.json(Map.of(
                    "projectId", projectId,
                    "clientId", clientId,
                    "message", "Client assigned successfully."
            ));
        });
        

        // Retrieves projects assigned to a client.
        // Local development only until secure authentication is added.
        app.get("/api/client/projects", ctx -> {

            String clientId = ctx.queryParam("clientId");

            if (clientId == null || clientId.isBlank()) {
                ctx.status(400).json(Map.of(
                        "error", "Client ID is required."
                ));
                return;
            }

            List<Map<String, Object>> clientProjects = new ArrayList<>();

            String sql = """
                    SELECT project_id, project_name, status,
                           progress, estimated_completion_date, budget
                    FROM projects
                    WHERE client_id = ?
                    ORDER BY project_name;
                    """;

            try (Connection connection = DatabaseManager.getConnection();
                 PreparedStatement statement =
                         connection.prepareStatement(sql)) {

                statement.setString(1, clientId);

                try (ResultSet result = statement.executeQuery()) {

                    while (result.next()) {

                        Map<String, Object> project = new HashMap<>();

                        project.put(
                                "projectId",
                                result.getString("project_id"));

                        project.put(
                                "projectName",
                                result.getString("project_name"));

                        project.put(
                                "status",
                                result.getString("status"));

                        project.put(
                                "progress",
                                result.getDouble("progress"));

                        project.put(
                                "estimatedCompletionDate",
                                result.getString("estimated_completion_date"));

                        project.put(
                                "budget",
                                result.getDouble("budget"));

                        clientProjects.add(project);
                    }
                }

                ctx.json(clientProjects);

            } catch (SQLException e) {

                System.out.println(
                        "Could not retrieve client projects: " + e.getMessage());

                ctx.status(500).json(Map.of(
                        "error", "Could not load client projects."
                ));
            }
        });




//      Creates a new construction project.
        app.post("/api/projects", ctx -> {

            ProjectRequest request =
                    ctx.bodyAsClass(
                            ProjectRequest.class);


//          Makes sure a project name was provided.
            if (request.getProjectName() == null ||
                    request.getProjectName()
                            .isBlank()) {

                ctx.status(400);

                ctx.json(Map.of(
                        "error",
                        "Project name is required."));

                return;
            }


//          Creates the project using the existing
//          ProjectManagementImpl component.
            String projectId =
                    projectManager.createProject(
                            request.getContractorId(),
                            request.getProjectName());


//          Checks that the project was created.
            if (projectId == null) {

                ctx.status(500);

                ctx.json(Map.of(
                        "error",
                        "Could not create project."));

                return;
            }


//          Stores the project's budget.
            boolean budgetUpdated =
                    expenseManager
                            .updateProjectBudget(
                                    projectId,
                                    request.getBudget());


//          Creates the response returned to React.
            Map<String, Object> response =
                    new HashMap<>();

            response.put(
                    "projectId",
                    projectId);

            response.put(
                    "projectName",
                    request.getProjectName());

            response.put(
                    "budget",
                    request.getBudget());

            response.put(
                    "status",
                    "ACTIVE");

            response.put(
                    "progress",
                    0);

            response.put(
                    "budgetUpdated",
                    budgetUpdated);


//          Sends the newly created project
//          back to the frontend.
            ctx.status(201);
            ctx.json(response);
        });
        
        
     // Adds a new expense to a construction project.
        app.post("/api/expenses", ctx -> {

            Map<String, Object> request =
                    ctx.bodyAsClass(Map.class);

            Object projectValue = request.get("projectId");
            Object descriptionValue = request.get("description");
            Object amountValue = request.get("amount");

            // Validates the required expense information.
            if (!(projectValue instanceof String projectId)
                    || projectId.isBlank()
                    || !(descriptionValue instanceof String description)
                    || description.isBlank()
                    || !(amountValue instanceof Number)) {

                ctx.status(400).json(Map.of(
                        "error", "Project, description, and amount are required."
                ));
                return;
            }

            double amount = ((Number) amountValue).doubleValue();

            // Makes sure the expense amount is valid.
            if (!Double.isFinite(amount) || amount <= 0) {

                ctx.status(400).json(Map.of(
                        "error", "Expense amount must be greater than zero."
                ));
                return;
            }

         // Checks that the project exists in SQLite.
            String checkProjectSql =
                    "SELECT 1 FROM projects WHERE project_id = ?";

            try (Connection connection = DatabaseManager.getConnection();
                 PreparedStatement statement =
                         connection.prepareStatement(checkProjectSql)) {

                statement.setString(1, projectId);

                try (ResultSet result = statement.executeQuery()) {

                    if (!result.next()) {
                        ctx.status(404).json(Map.of(
                                "error", "Project not found."
                        ));
                        return;
                    }
                }

            } catch (SQLException e) {

                e.printStackTrace();

                ctx.status(500).json(Map.of(
                        "error", "Could not verify project."
                ));
                return;
            }

            // Saves the expense in the SQLite database.
            String expenseId = expenseManager.addExpense(
                    projectId,
                    description.trim(),
                    amount
            );

            // Checks that the expense was saved successfully.
            if (expenseId == null) {

                ctx.status(500).json(Map.of(
                        "error", "Could not save expense."
                ));
                return;
            }

            // Returns the saved expense information to React.
            ctx.status(201).json(Map.of(
                    "expenseId", expenseId,
                    "projectId", projectId,
                    "description", description.trim(),
                    "amount", amount
            ));
        });
        

        // Adds a material to a construction project.
        app.post("/api/materials", ctx -> {

            Map<String, Object> request =
                    ctx.bodyAsClass(Map.class);

            Object projectValue = request.get("projectId");
            Object nameValue = request.get("materialName");
            Object quantityValue = request.get("quantity");

            if (!(projectValue instanceof String projectId)
                    || projectId.isBlank()
                    || !(nameValue instanceof String materialName)
                    || materialName.isBlank()
                    || !(quantityValue instanceof Number)) {

                ctx.status(400).json(Map.of(
                        "error", "Project, material name, and quantity are required."
                ));
                return;
            }

            double quantity = ((Number) quantityValue).doubleValue();

            if (!Double.isFinite(quantity) || quantity <= 0) {
                ctx.status(400).json(Map.of(
                        "error", "Quantity must be greater than zero."
                ));
                return;
            }

            String materialId = materialManager.addMaterial(
                    projectId, materialName.trim(), quantity
            );

            if (materialId == null) {
                ctx.status(500).json(Map.of(
                        "error", "Could not add material."
                ));
                return;
            }

            ctx.status(201).json(Map.of(
                    "materialId", materialId,
                    "projectId", projectId,
                    "materialName", materialName.trim(),
                    "quantity", quantity
            ));
        });


        // Updates the quantity of an existing material.
        app.put("/api/materials/{id}/quantity", ctx -> {

            String materialId = ctx.pathParam("id");
            Map<String, Object> request = ctx.bodyAsClass(Map.class);

            Object quantityValue = request.get("quantity");

            if (!(quantityValue instanceof Number)) {
                ctx.status(400).json(Map.of(
                        "error", "A valid quantity is required."
                ));
                return;
            }

            double quantity = ((Number) quantityValue).doubleValue();

            if (!Double.isFinite(quantity) || quantity < 0) {
                ctx.status(400).json(Map.of(
                        "error", "Quantity cannot be negative."
                ));
                return;
            }

            boolean updated = materialManager.updateMaterialQuantity(
                    materialId, quantity
            );

            if (!updated) {
                ctx.status(404).json(Map.of(
                        "error", "Material not found."
                ));
                return;
            }

            ctx.json(Map.of(
                    "materialId", materialId,
                    "quantity", quantity,
                    "message", "Material quantity updated successfully."
            ));
        });


        // Adds equipment to a construction project.
        app.post("/api/equipment", ctx -> {

            Map<String, Object> request = ctx.bodyAsClass(Map.class);

            Object projectValue = request.get("projectId");
            Object nameValue = request.get("equipmentName");

            if (!(projectValue instanceof String projectId)
                    || projectId.isBlank()
                    || !(nameValue instanceof String equipmentName)
                    || equipmentName.isBlank()) {

                ctx.status(400).json(Map.of(
                        "error", "Project and equipment name are required."
                ));
                return;
            }

            String equipmentId = materialManager.addEquipment(
                    projectId, equipmentName.trim()
            );

            if (equipmentId == null) {
                ctx.status(500).json(Map.of(
                        "error", "Could not add equipment."
                ));
                return;
            }

            ctx.status(201).json(Map.of(
                    "equipmentId", equipmentId,
                    "projectId", projectId,
                    "equipmentName", equipmentName.trim()
            ));
        });
        
     // Removes an expense from a project.
        app.delete("/api/expenses/{id}", ctx -> {
            String expenseId = ctx.pathParam("id");

            boolean removed = expenseManager.removeExpense(expenseId);

            if (!removed) {
                ctx.status(404).json(Map.of(
                        "error", "Expense not found."
                ));
                return;
            }

            ctx.json(Map.of(
                    "expenseId", expenseId,
                    "message", "Expense removed successfully."
            ));
        });
        
     // Removes a material from a project.
        app.delete("/api/materials/{id}", ctx -> {

            String materialId = ctx.pathParam("id");

            boolean removed = materialManager.removeMaterial(materialId);

            if (!removed) {
                ctx.status(404).json(Map.of(
                        "error", "Material not found."
                ));
                return;
            }

            ctx.json(Map.of(
                    "materialId", materialId,
                    "message", "Material removed successfully."
            ));
        });


        // Removes equipment from a project.
        app.delete("/api/equipment/{id}", ctx -> {

            String equipmentId = ctx.pathParam("id");

            boolean removed = materialManager.removeEquipment(equipmentId);

            if (!removed) {
                ctx.status(404).json(Map.of(
                        "error", "Equipment not found."
                ));
                return;
            }

            ctx.json(Map.of(
                    "equipmentId", equipmentId,
                    "message", "Equipment removed successfully."
            ));
        });


        // Retrieves materials and equipment for a project.
        app.get("/api/projects/{id}/inventory", ctx -> {

            String projectId = ctx.pathParam("id");

            List<Map<String, Object>> materials = new ArrayList<>();
            List<Map<String, Object>> equipment = new ArrayList<>();

            String materialsSql = """
                    SELECT material_id, material_name, quantity
                    FROM materials
                    WHERE project_id = ?
                    ORDER BY rowid DESC;
                    """;

            String equipmentSql = """
                    SELECT equipment_id, equipment_name
                    FROM equipment
                    WHERE project_id = ?
                    ORDER BY rowid DESC;
                    """;

            try (Connection connection = DatabaseManager.getConnection()) {

                try (PreparedStatement statement =
                             connection.prepareStatement(materialsSql)) {

                    statement.setString(1, projectId);

                    try (ResultSet results = statement.executeQuery()) {

                        while (results.next()) {
                            materials.add(Map.of(
                                    "materialId", results.getString("material_id"),
                                    "materialName", results.getString("material_name"),
                                    "quantity", results.getDouble("quantity")
                            ));
                        }
                    }
                }

                try (PreparedStatement statement =
                             connection.prepareStatement(equipmentSql)) {

                    statement.setString(1, projectId);

                    try (ResultSet results = statement.executeQuery()) {

                        while (results.next()) {
                            equipment.add(Map.of(
                                    "equipmentId", results.getString("equipment_id"),
                                    "equipmentName", results.getString("equipment_name")
                            ));
                        }
                    }
                }

                ctx.json(Map.of(
                        "projectId", projectId,
                        "materials", materials,
                        "equipment", equipment
                ));

            } catch (SQLException e) {
                e.printStackTrace();

                ctx.status(500).json(Map.of(
                        "error", "Could not retrieve project inventory."
                ));
            }
        });

        
     // Retrieves all expenses for a specific project.
        app.get("/api/projects/{id}/expenses", ctx -> {

            String projectId = ctx.pathParam("id");

            List<Map<String, Object>> expenses = new ArrayList<>();

            String sql = """
                    SELECT expense_id, project_id, description, amount
                    FROM expenses
                    WHERE project_id = ?
                    ORDER BY rowid DESC;
                    """;

            try (Connection connection = DatabaseManager.getConnection();
                 PreparedStatement statement =
                         connection.prepareStatement(sql)) {

                statement.setString(1, projectId);

                try (ResultSet result = statement.executeQuery()) {

                    while (result.next()) {

                        Map<String, Object> expense = new HashMap<>();

                        expense.put("expenseId",
                                result.getString("expense_id"));

                        expense.put("projectId",
                                result.getString("project_id"));

                        expense.put("description",
                                result.getString("description"));

                        expense.put("amount",
                                result.getDouble("amount"));

                        expenses.add(expense);
                    }
                }

                ctx.json(expenses);

            } catch (SQLException e) {

                e.printStackTrace();

                ctx.status(500).json(Map.of(
                        "error", "Could not retrieve expenses."
                ));
            }
        });


        // Retrieves the total amount spent on a project.
        app.get("/api/projects/{id}/expenses/total", ctx -> {

            String projectId = ctx.pathParam("id");

            double totalExpenses =
                    expenseManager.getProjectExpenses(projectId);

            ctx.json(Map.of(
                    "projectId", projectId,
                    "totalExpenses", totalExpenses
            ));
        });


        // Retrieves the remaining project budget.
        app.get("/api/projects/{id}/budget/remaining", ctx -> {

            String projectId = ctx.pathParam("id");

            double remainingBudget =
                    expenseManager.getRemainingBudget(projectId);

            ctx.json(Map.of(
                    "projectId", projectId,
                    "remainingBudget", remainingBudget
            ));
        });
        

//      Updates an existing project's information.
        app.put("/api/projects/{id}", ctx -> {
            String projectId = ctx.pathParam("id");
            Map<String, Object> request = ctx.bodyAsClass(Map.class);
            Object nameValue = request.get("projectName");
            Object progressValue = request.get("progress");
            Object dateValue = request.get("estimatedCompletionDate");
            Object budgetValue = request.get("budget");

            // Validates the project information.
            if (!(nameValue instanceof String projectName)
                    || projectName.isBlank()
                    || !(progressValue instanceof Number)
                    || !(budgetValue instanceof Number)
                    || (dateValue != null && !(dateValue instanceof String))) {
                ctx.status(400).json(Map.of(
                        "error", "Valid project name, progress, date, and budget are required."
                ));
                return;
            }

            double progress = ((Number) progressValue).doubleValue();
            double budget = ((Number) budgetValue).doubleValue();

            if (!Double.isFinite(progress) || progress < 0 || progress > 100
                    || !Double.isFinite(budget) || budget < 0) {
                ctx.status(400).json(Map.of(
                        "error", "Progress must be between 0 and 100, and budget cannot be negative."
                ));
                return;
            }

            // Retrieves the existing project without changing its assignments.
            model.Project existingProject = null;
            for (model.Project project : projectManager.getAllProjects()) {
                if (projectId.equals(project.getProjectId())) {
                    existingProject = project;
                    break;
                }
            }

            if (existingProject == null) {
                ctx.status(404).json(Map.of(
                        "error", "Project not found."
                ));
                return;
            }

            if ("ARCHIVED".equals(existingProject.getStatus())) {
                ctx.status(409).json(Map.of(
                        "error", "Archived projects cannot be edited."
                ));
                return;
            }

            // Updates only the editable project fields.
            existingProject.setProjectName(projectName.trim());
            existingProject.setProgress(progress);
            existingProject.setEstimatedCompletionDate(
                    dateValue == null ? null : ((String) dateValue).trim()
            );
            existingProject.setBudget(budget);

            boolean updated = projectManager.updateProject(existingProject);

            if (!updated) {
                ctx.status(500).json(Map.of(
                        "error", "Could not update project."
                ));
                return;
            }

            ctx.json(Map.of(
                    "projectId", projectId,
                    "message", "Project updated successfully."
            ));
        });

        

//      Archives a project without deleting its information.
        app.delete("/api/projects/{id}", ctx -> {
            String projectId = ctx.pathParam("id");

            if (projectId == null || projectId.isBlank()) {
                ctx.status(400).json(Map.of(
                        "error", "Project ID is required."
                ));
                return;
            }

            boolean archived = projectManager.deleteProject(projectId);

            if (!archived) {
                ctx.status(404).json(Map.of(
                        "error", "Project not found or already archived."
                ));
                return;
            }

            ctx.json(Map.of(
                    "projectId", projectId,
                    "status", "ARCHIVED",
                    "message", "Project archived successfully."
            ));
        });



//      Returns all projects currently
//      stored in the SQLite database.
        app.get("/api/projects", ctx -> {

            ctx.json(
                    projectManager.getAllProjects());
        });
        

//      Updates the status of an existing project.
        app.put("/api/projects/{id}/status", ctx -> {
            String projectId = ctx.pathParam("id");
            Map<String, Object> request = ctx.bodyAsClass(Map.class);
            Object statusValue = request.get("status");
            if (!(statusValue instanceof String status) || status.isBlank()) {
                ctx.status(400).json(Map.of(
                        "error", "Project status is required."
                ));
                return;
            }
            String updatedStatus = status.trim().toUpperCase();
            if (!updatedStatus.equals("ACTIVE")
                    && !updatedStatus.equals("ON_HOLD")
                    && !updatedStatus.equals("COMPLETED")) {
                ctx.status(400).json(Map.of(
                        "error", "Status must be ACTIVE, ON_HOLD, or COMPLETED."
                ));
                return;
            }
            boolean updated = projectManager.updateProjectStatus(
                    projectId, updatedStatus
            );
            if (!updated) {
                ctx.status(404).json(Map.of(
                        "error", "Project not found or archived."
                ));
                return;
            }
            ctx.json(Map.of(
                    "projectId", projectId,
                    "status", updatedStatus,
                    "message", "Project status updated successfully."
            ));
        });
        
        

//      Retrieves detailed information about a specific project.
        app.get("/api/projects/{id}", ctx -> {
            String projectId = ctx.pathParam("id");
            if (projectId == null || projectId.isBlank()) {
                ctx.status(400).json(Map.of(
                        "error", "Project ID is required."
                ));
                return;
            }
            for (model.Project project : projectManager.getAllProjects()) {
                if (projectId.equals(project.getProjectId())) {
                    ctx.json(project);
                    return;
                }
            }
            ctx.status(404).json(Map.of(
                    "error", "Project not found."
            ));
        });



//      Returns all workers currently
//      stored in the SQLite database.
        app.get("/api/workers", ctx -> {

            ctx.json(
                    workforceManager.getAllWorkers());
        });
        
//      Deactivates a worker without deleting their work history.
        app.delete("/api/workers/{id}", ctx -> {

            String workerId = ctx.pathParam("id");

            if (workerId == null || workerId.isBlank()) {
                ctx.status(400).json(
                    Map.of("error", "Worker ID is required.")
                );
                return;
            }

            boolean deactivated = workforceManager.deactivateWorker(workerId);

            if (!deactivated) {
                ctx.status(404).json(
                    Map.of("error", "Worker not found or already deactivated.")
                );
                return;
            }

            ctx.status(200).json(
                Map.of(
                    "workerId", workerId,
                    "message", "Worker deactivated successfully."
                )
            );
        });
        
//      Retrieves all inactive workers.
        app.get("/api/workers/inactive", ctx -> {

            ctx.json(workforceManager.getInactiveWorkers());

        });


        // Reactivates a previously deactivated worker.
        app.put("/api/workers/{id}/reactivate", ctx -> {

            String workerId = ctx.pathParam("id");

            if (workerId == null || workerId.isBlank()) {

                ctx.status(400).json(Map.of(
                        "error", "Worker ID is required."
                ));

                return;
            }

            boolean reactivated =
                    workforceManager.reactivateWorker(workerId);

            if (!reactivated) {

                ctx.status(404).json(Map.of(
                        "error", "Worker not found or already active."
                ));

                return;
            }

            ctx.status(200).json(Map.of(
                    "workerId", workerId,
                    "message", "Worker reactivated successfully."
            ));

        });


//      Adds a new worker to a project.
        app.post("/api/workers", ctx -> {

            WorkerRequest request =
                    ctx.bodyAsClass(
                            WorkerRequest.class);


//          Makes sure the required worker
//          information was provided.
            if (request.getProjectId() == null ||
                    request.getProjectId().isBlank() ||
                    request.getWorkerName() == null ||
                    request.getWorkerName().isBlank() ||
                    request.getTrade() == null ||
                    request.getTrade().isBlank()) {

                ctx.status(400);

                ctx.json(Map.of(
                        "error",
                        "Project, worker name, and trade are required."));

                return;
            }


//          Adds the worker using the existing
//          WorkforceManagementImpl component.
            String workerId =
                    workforceManager.addWorker(
                            request.getProjectId(),
                            request.getWorkerName(),
                            request.getTrade());


//          Checks that the worker was created.
            if (workerId == null) {

                ctx.status(500);

                ctx.json(Map.of(
                        "error",
                        "Could not add worker."));

                return;
            }


//          Creates the worker information
//          returned to the React frontend.
            Map<String, Object> response =
                    new HashMap<>();

            response.put(
                    "workerId",
                    workerId);

            response.put(
                    "projectId",
                    request.getProjectId());

            response.put(
                    "workerName",
                    request.getWorkerName());

            response.put(
                    "trade",
                    request.getTrade());

            response.put(
                    "area",
                    "");

            response.put(
                    "taskId",
                    "");


//          Sends the newly created worker
//          back to the frontend.
            ctx.status(201);
            ctx.json(response);
        });
        
     // Assigns or reassigns a worker to an area and task.
        app.put("/api/workers/{id}/assignment", ctx -> {

            String workerId = ctx.pathParam("id");

            Map<String, String> request =
                    ctx.bodyAsClass(Map.class);

            String projectId = request.get("projectId");
            String area = request.get("area");
            String task = request.get("task");

            if (projectId == null || projectId.isBlank() ||
                    area == null || area.isBlank() ||
                    task == null || task.isBlank()) {

                ctx.status(400);
                ctx.json(Map.of(
                        "error",
                        "Project, area, and task are required."));
                return;
            }

            boolean updated = workforceManager.assignWorker(
                    workerId,
                    projectId,
                    area,
                    task);

            if (!updated) {
                ctx.status(404);
                ctx.json(Map.of(
                        "error",
                        "Worker not found or assignment failed."));
                return;
            }

            ctx.json(Map.of(
                    "workerId", workerId,
                    "projectId", projectId,
                    "area", area,
                    "taskId", task
            ));
        });
        
     // Records the hours a worker spent on an assigned task.
        app.post("/api/workers/{id}/hours", ctx -> {

            String workerId = ctx.pathParam("id");

            Map<String, Object> request = ctx.bodyAsClass(Map.class);

            Object taskValue = request.get("taskId");
            Object hoursValue = request.get("hours");
            Object dateValue = request.get("workDate");

            if (!(taskValue instanceof String)
                    || ((String) taskValue).isBlank()
                    || !(hoursValue instanceof Number)
                    || !(dateValue instanceof String)
                    || ((String) dateValue).isBlank()) {

                ctx.status(400);
                ctx.json(Map.of(
                    "error", "Valid task ID, hours, and work date are required."
                ));
                return;
            }

            String taskId = ((String) taskValue).trim();
            double hours = ((Number) hoursValue).doubleValue();
            String workDate = ((String) dateValue).trim();

            if (!Double.isFinite(hours) || hours <= 0) {
                ctx.status(400);
                ctx.json(Map.of(
                    "error", "Hours must be greater than zero."
                ));
                return;
            }

            // Validates the work date format.
            try {
                java.time.LocalDate.parse(workDate);

            } catch (java.time.format.DateTimeParseException e) {

                ctx.status(400);
                ctx.json(Map.of(
                    "error", "Work date must be a valid date in YYYY-MM-DD format."
                ));
                return;
            }

            boolean saved = workforceManager.recordWorkHours(
                workerId,
                taskId,
                hours,
                workDate
            );

            if (!saved) {
                ctx.status(400);
                ctx.json(Map.of(
                    "error", "Could not record work hours. Check the worker, task, hours, and date."
                ));
                return;
            }

            ctx.status(201);
            ctx.json(Map.of(
                "workerId", workerId,
                "taskId", taskId,
                "hours", hours,
                "workDate", workDate,
                "message", "Work hours recorded successfully."
            ));

        });
        
     // Retrieves all recorded work hours for a worker.
        app.get("/api/workers/{id}/hours", ctx -> {

            String workerId = ctx.pathParam("id");

            List<Map<String, Object>> workHours = new ArrayList<>();

            String sql =
                "SELECT id, worker_id, task_id, hours, work_date " +
                "FROM work_hours " +
                "WHERE worker_id = ? " +
                "ORDER BY work_date DESC, id DESC";

            try (Connection connection = DatabaseManager.getConnection();
                 PreparedStatement statement = connection.prepareStatement(sql)) {

                statement.setString(1, workerId);

                try (ResultSet results = statement.executeQuery()) {

                    while (results.next()) {

                        Map<String, Object> record = new HashMap<>();

                        record.put("id", results.getInt("id"));
                        record.put("workerId", results.getString("worker_id"));
                        record.put("taskId", results.getString("task_id"));
                        record.put("hours", results.getDouble("hours"));
                        record.put("workDate", results.getString("work_date"));

                        workHours.add(record);
                    }
                }

                ctx.json(workHours);

            } catch (SQLException exception) {

                exception.printStackTrace();

                ctx.status(500).json(
                    Map.of("error", "Could not retrieve work hours.")
                );
            }
        });  
        

        // Retrieves a change order by its ID.
        // Development-only route until authentication is implemented.
        app.get("/api/change-orders/{id}", ctx -> {

            String changeOrderId = ctx.pathParam("id");

            ChangeOrder changeOrder =
                    changeOrderManager.getChangeOrder(changeOrderId);

            if (changeOrder == null) {

                ctx.status(404).json(Map.of(
                        "error", "Change order not found."
                ));
                return;
            }

            ctx.json(changeOrder);
        });
        
	     // Retrieves all change orders for a project.
	     // Development-only until project authorization is implemented.
	     app.get("/api/projects/{id}/change-orders", ctx -> {
	
	         String projectId = ctx.pathParam("id");
	
	         ctx.json(
	                 changeOrderManager.getProjectChangeOrders(projectId)
	         );
	     });
        
        

//      Starts the backend on port 7070.
        app.start(7070);
    }
}