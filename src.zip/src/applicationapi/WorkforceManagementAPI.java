package applicationapi;

import java.util.List;

import model.Worker;

/*
 * This interface is responsible for:
 * Handling workers, trades, assignments, and work hours.
 * Allowing the contractor to manage the work-force.
 */
public interface WorkforceManagementAPI {

//	Adds a worker to a project and records their trade.
	String addWorker(
			String projectId,
			String workerName,
			String trade);

//	Assigns a worker to a specific area and task.
	boolean assignWorker(
			String workerId,
			String projectId,
			String area,
			String task);

//	Relocating workers to another project area or task.
	boolean reassignWorker(
	        String workerId,
	        String newArea,
	        String newTask);

//	Records the hours worked on a task for a selected date.
	boolean recordWorkHours(
	        String workerId,
	        String taskId,
	        double hours,
	        String workDate);

//	Retrieves summarized work-force information.
	String getProjectWorkforce(
			String projectId);

//	Retrieves all workers stored in the system.
	List<Worker> getAllWorkers();
	
//	Deactivates a worker without deleting their work history.
	boolean deactivateWorker(String workerId);
	
//	Reactivates an inactive worker without creating a new record.
	boolean reactivateWorker(String workerId);

//	Retrieves workers who have been deactivated.
	List<Worker> getInactiveWorkers();
}